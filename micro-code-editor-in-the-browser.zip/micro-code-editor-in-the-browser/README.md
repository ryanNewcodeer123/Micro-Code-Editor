# Micro Code Editor in the Browser!

A Pen created on CodePen.io. Original URL: [https://codepen.io/kazzkiq/pen/xGXaKR](https://codepen.io/kazzkiq/pen/xGXaKR).

No CodeMirror nor tons of files and weighty functions. This editor is made using only a little of CSS+JavaScript and the awesome Prism.js plugin for highlight!

Perfect fit for landing pages or when you want the user to edit or play with small pieces of code.